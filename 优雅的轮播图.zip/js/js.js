(function () {
    //页面加载完成时执行
    window.onload = function () {
        var container = document.getElementById("container"), //总的区域
            list = document.getElementById("list"), //图片总区域
            buttons = document.getElementById("buttons"),//小圆点(总)
            buttons_sapn = buttons.getElementsByTagName('span'), ////小圆点(多)
            prev = document.getElementById("prev"),//看上一幅图
            next = document.getElementById("next"),//看下一幅图
            index = 1, //当前展示第一副图
            timer = null, //定时器
            aTimer = null, //缓冲定时器
            lock = false; //锁住定时器 false--> 解锁  true---》启动

        const WID = 600,
            IND = 5;

        for (var i = 0, len = buttons_sapn.length; i < len; i++) {
            var span = buttons_sapn[i];
            span.setAttribute("data_index", i+1);
        }

        //定义动态效果  //iTarget水平的目标
        function animate(iTarget) {
            var newLeft = parseInt(list.style.left) + iTarget; //移动的目标
            buttonsShow();
            //list.style.left = newLeft + 'px';
            stopBuffer();
            stop();

            aTimer = setInterval(function () {
                var iSpeed = (newLeft - list.offsetLeft) / 12; //缓冲运动的速度
                lock = true;
                iSpeed >= 0 ? iSpeed = Math.ceil(iSpeed) : iSpeed = Math.floor(iSpeed);
                list.style.left = parseInt(getComputedStyle(list).left) + iSpeed + 'px';
                if (parseInt(getComputedStyle(list).left) === newLeft) {
                    lock = false;
                    stopBuffer();
                    boRoll();
                }
            }, 30);
        };

        //无限滚动判断
        function boRoll() {
            if (index === 1) {
                list.style.left = -WID + 'px';
            } else if (index === IND) {
                list.style.left = -WID * IND + 'px';
            }
        };

        //定时器设置
        function play() {
            timer = setInterval(function () {
                next.onclick();
            }, 2000);
        };

        //关闭定时器
        function stop() {
            clearInterval(timer);
        };

        //关闭缓冲定时器
        function stopBuffer() {
            clearInterval(aTimer);
        };

        //1.整负一  2.
        function clickMove(num) {
            if (lock) { //如果锁开启的话，点击事件没有启动
                return false;
            }
            index += num;

            if (num === 1) {
                index > IND && ( index = 1 );
                animate(-WID);
            } else if (num === -1) {
                index < 1 && (index = IND);
                animate(WID);
            }
        };
        //修改小圆点
        function buttonsShow() {
            var redd = buttons.getElementsByClassName('on')[0];
            if (redd) {
                redd.className = "";
            }

            buttons.getElementsByTagName("span")[index - 1].className = "on";
        };

        //开启定时器
        play();

        //给每个小圆点添加点击事件
        buttons.onclick = function (ev) {
            var target = ev.target;
            if (target.tagName === 'SPAN' && target.className !== 'on') {
                //var newCur = parseInt(target.getAttribute('data_index')), //当前点击的小圆点下标
                //    oldCur = parseInt(buttons.getElementsByClassName('on')[0].getAttribute('data_index'));//以前点击的小圆点

                var newCur = parseInt(target.getAttribute('data_index')), //当前点击的小圆点下标
                    oldCur = parseInt(buttons.getElementsByClassName('on')[0].getAttribute('data_index'));//以前点击的小圆点
                index = newCur;
                animate(-WID * (newCur - oldCur ));
            }
        };

        //点击右边的下一副图
        next.onclick = function () {
            clickMove(1);
        };

        //点击左边的上一副图
        prev.onclick = function () {
            clickMove(-1);
        };

        container.onmouseover = function () {
            stop();
        };

        container.onmouseleave = function () {
            play();
        };
    };
})();











